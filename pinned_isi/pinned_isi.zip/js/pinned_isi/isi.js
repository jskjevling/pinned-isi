/*
  Pinned ISI Module
  Author: Jeremy Skjevling/Multimedia Services
  Useage: This module is meant as a plug-and-play solution to all pinned ISI needs.
          It loads the ISI text/markup from a separate file, and generates the pinned
          ISI based on window size using specified breakpoints.

          The plugin exposes a public API with the following available properties and methods:


*/

'use strict'

var isi = (function buildModule(options){

  /*get the current viewport size*/

  var currentView = {},

      /* Holds the bounding box for the isi */

      currentPosition,

      /* Boolean to track if ISI is on screen */

      isInView = false,

      /* calculated current style properties based on current breakpoint */

      styleProps = {
        pinned: {
          top: '75%',
          position: 'fixed'
        },
        expanded: {
          top: '8px',
          position: 'absolute'
        },
        flow: {
          top: '',
          position: 'static'
        }
      },

      /* To hold the custom styles defined in the options object, based on the current breakpoint */

      customStyles = {
        pinned: {},
        expanded: {},
        flow: {}
      },

      /* To hold the styles for the expand/retract buttons based on the current breakpoint */

      expBtnStyleProps = {
        pinned: {
          
        },
        expanded: {
          
        },
        flow: {
          
        }
      },

      /* Values to hold expand/retract button text */

      expandTextPinned,
      retractTextPinned,
      expandTextExp,
      retractTextExp,
      expandTextFlow,
      retractTextFlow,

      /* cached numeric version of pinned top height for calcualtions */

      pinnedTop,

      /* dummy element to swap for ISI when pinned */

      dummy = document.createElement('div'),

      /* Holds a reference to the body element for scrolling calculations */

      pageBody = document.querySelector('body'),

      /* =============================================================
         Javascript scrolling elements for mobile scroll hijacking 
         ============================================================= */

      /* Boolean sets true if touch is enabled */

      isMobile = false,

      /* The sub-view that holds the page content meant to scroll under the ISI */

      view = document.getElementById('page-content'),

      /* Mobile scroll bar indicator */

      indicator = document.getElementById('indicator'),

      /* */

      relative,
      
      /* */
      
      min,
      
      /* */
      
      max,
      
      /* */
      
      offset = min = 0,
      
      /* */
      
      reference,
      
      /* */
      
      pressed = false,
      
      /* */
      
      xform = 'transform',
      
      /* */
      
      velocity,
      
      /* */
      
      amplitude,
      
      /* */
      
      target,
      
      /* */
      
      frame,
      
      /* */
      
      timestamp,
      
      /* */
      
      ticker,
      
      /* */
      
      now,
      
      /* */
      
      elapsed,
      
      /* */
      
      y,
      
      /* */
      
      delta,
      
      /* */
      
      v,
      
      /* */
      
      timeConstant = 325,
      
      /* ============================================================
         End javascript scroll elements
         ============================================================ */

      /*  */

      bodyBinding,
      scrollTimeout,
      resizeTimeout,
      mobileCrossover;

  /* These first few utilities are just for the purpose of checking whether or not a 
  passed value in the options object is a valid HTML element, and a third utility for
  checking for the presence of certain class names. */

  var isElement = function isElement(o){
        return (
          typeof HTMLElement === "object" ? o instanceof HTMLElement : //DOM2
          o && typeof o === "object" && o !== null && o.nodeType === 1 && typeof o.nodeName === "string"
        );
      },

      isNode = function isNode(o){
        return (
          typeof Node === "object" ? o instanceof Node :
          o && typeof o === "object" && typeof o.nodeType === "number" && typeof o.nodeName === "string"
        );
      },

      hasClass = function hasClass(element, cls) {
        return (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
      },

      /* Here we set up the predefined XMLHttpRequest object and load in the text or 
      HTML file specified via the path option of the options object */

      loadText = function loadText() {

        //publicAPI.req.overrideMimeType('text/plain');
        publicAPI.req.open('GET', publicAPI.filePath, true);
        publicAPI.req.addEventListener('load', textLoadResponder);
        publicAPI.req.send(null);
      
      },

      /* Instantiate the buildISI variable (will house the method later) */

      buildISI,

      /*
        Iterate through the breakpoints checking for a min/max range that the current
        window falls within.  Once identified, apply the related styles to the style
        object for the ISI and expand button respectively.
      */

      calculateBreakpoint = function calcualteBreakpoint() {
        for (var breakpoint in options.breakpoints) {
          if (options.breakpoints[breakpoint].minWidth <= currentView.width && options.breakpoints[breakpoint].maxWidth >= currentView.width) {
            return options.breakpoints[breakpoint];
          };
        }
      },

      /* */

      showIndication = function showIndication(state) {
        if (state) {
          if (publicAPI.mobileInd) {
            publicAPI.mobileInd.style.display = 'block';
          }
          if (publicAPI.mainInd) {
            publicAPI.mainInd.style.display = 'none';
          }
        } else {
          if (publicAPI.mobileInd) {
            publicAPI.mobileInd.style.display = 'none';
          }
          if (publicAPI.mainInd) {
            publicAPI.mainInd.style.display = 'block';
          }
        }
      },

      /* */

      applyBreakpoint = function applyBreakpoint(breakpoint) {
        showIndication(breakpoint.mobileStacking);
        styleProps.pinned = breakpoint.pinned.isi;
        customStyles.pinned = breakpoint.pinned.customStyles;
        expBtnStyleProps.pinned = breakpoint.pinned.expandBtn;
        expandTextPinned = breakpoint.pinned.expandText;
        retractTextPinned = breakpoint.pinned.retractText;
        styleProps.expanded = breakpoint.expanded.isi;
        customStyles.expanded = breakpoint.expanded.customStyles;
        expBtnStyleProps.expanded = breakpoint.expanded.expandBtn;
        expandTextExp = breakpoint.expanded.expandText;
        retractTextExp = breakpoint.expanded.retractText;
        styleProps.flow = breakpoint.flow.isi;
        customStyles.flow = breakpoint.flow.customStyles;
        expBtnStyleProps.flow = breakpoint.flow.expandBtn;
        expandTextFlow = breakpoint.flow.expandText;
        retractTextFlow = breakpoint.flow.retractText;
        applyStyles();
        applyExpandBtnStyles();
      },

      /* Once we have a response from the get request, we can begin to build the ISI
      from the loaded information/markup/etc.  This load responder assigns the loaded
      content to the isiMarkup property and the innerHTML of the wrapper element that
      was passed in.  We then log the position on the page, build and link up the 
      "Expand" button, and pin the ISI depending on screen size, via the breakpoints
      that were set. */

      textLoadResponder = function textLoadResponder() {

        publicAPI.wrapper.innerHTML = publicAPI.isiMarkup = publicAPI.req.response ? publicAPI.req.response : '<p>Please include the necessary markup within the isi.html file located in the pinned.isi folder.  Please note: this should be a document fragment.  Do not include doctype, head, or body tags.  All tags should be compatible for display within the body tag.  The html file extension is only used to ease syntax highlighting in most modern editors.</p>';
        buildISI();
      },

      /* Cross browser viewport check (returns width and height) */

      viewport = function viewport() {
        var e = window, a = 'inner';
        if ( !( 'innerWidth' in window ) ) {
          a = 'client';
          e = document.documentElement || document.body;
        }
        return { width : e[ a+'Width' ] , height : e[ a+'Height' ] }
      },

      /* Handle browser check to implement javascript scrolling for mobile devices */

      checkBrowser = function checkBrowser() {
        var ua=navigator.userAgent,tem,M=ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || []; 
        if(/trident/i.test(M[1])){
            tem=/\brv[ :]+(\d+)/g.exec(ua) || []; 
            return {name:'IE',version:(tem[1]||'')};
            }   
        if(M[1]==='Chrome'){
            tem=ua.match(/\bOPR\/(\d+)/)
            if(tem!=null)   {return {name:'Opera', version:tem[1]};}
            }   
        M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
        if((tem=ua.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
        return {
          name: M[0],
          version: M[1]
        };
      },

      /* Configure the dummy block that replaces ISI content on the page while ISI is 
      pinned, and append it to the ISI's parent element */

      buildDummy = function buildDummy() {
        dummy.style.height = publicAPI.position.height + 'px';
        dummy.style.width = publicAPI.position.width + 'px';
        publicAPI.parent.insertBefore(dummy,publicAPI.wrapper);
      },

      /* Applies styles related to the current state of the ISI. Styles are derived from 
      the breakpoints property of the options object, current styles are calculated based
      on screen size */

      applyStyles = function applyStyles() {
        /* Convert the style information for the pinned top value to numeric value for calculations */
        pinnedTop = styleProps.pinned.top.indexOf('%') ? (Number(styleProps.pinned.top.slice(0,styleProps.pinned.top.indexOf('%')))*.01)*currentView.height : Number(styleProps.pinned.top.slice(0,styleProps.pinned.top.indexOf('p')));
        /* Loop through the related styles and apply based on state information */
        for (var styleName in styleProps[publicAPI.state]) {
          publicAPI.wrapper.style[styleName] = styleProps[publicAPI.state][styleName];
        }
        for (var element in customStyles[publicAPI.state]) {
          var el = document.querySelector(customStyles[publicAPI.state][element]['selector']);
          for (var s in customStyles[publicAPI.state][element]['styles']) {
            el.style[s] = customStyles[publicAPI.state][element]['styles'][s];
          }
        }
      },

      /* */

      applyExpandBtnStyles = function applyExpandBtnStyles() {
        /* Loop through the related styles and apply based on state information */
        for (var styleName in expBtnStyleProps[publicAPI.state]) {
          publicAPI.isiBtn.style[styleName] = expBtnStyleProps[publicAPI.state][styleName];
          publicAPI.indBtn.style[styleName] = expBtnStyleProps[publicAPI.state][styleName];
        }
        if (publicAPI.isiBtn) {
          switch (publicAPI.state) {
            case 'pinned':
              publicAPI.isiBtn.innerHTML = expandTextPinned;
              break;
            case 'expanded':
              publicAPI.isiBtn.innerHTML = expandTextExp;
              break;
            case 'flow':
              publicAPI.isiBtn.innerHTML = expandTextFlow;
              break;
          }
        }
        if (publicAPI.indBtn) {
          switch (publicAPI.state) {
            case 'pinned':
              publicAPI.indBtn.innerHTML = expandTextPinned;
              break;
            case 'expanded':
              publicAPI.indBtn.innerHTML = expandTextExp;
              break;
            case 'flow':
              publicAPI.indBtn.innerHTML = expandTextFlow;
              break;
          }
        }
      },

      /* */

      scrollResponder = function scrollResponder(){
        if(scrollTimeout){ clearTimeout(scrollTimeout); }
        scrollTimeout = setTimeout(function(){
          publicAPI.checkPos();
        },10);
      },

      /* */

      resizeResponder = function resizeResponder(){
        if(!!resizeTimeout){ clearTimeout(resizeTimeout); }
        resizeTimeout = setTimeout(function(){
          buildISI(true);
        },200);
      },

      /* */

      orientationResponder = function orientationResponder(){
        buildISI(true);
      },

      /* */

      ypos = function ypos(e){
        /* touch event */

        if (e.targetTouches && (e.targetTouches.length >= 1)) {
          return e.targetTouches[0].clientY;
        }

        /* mouse event */

        return e.clientY;

      },

      scroll = function scroll(y){

        offset = (y > max) ? max : (y < min) ? min : y;
        view.style[xform] = 'translateY(' + (-offset) + 'px)';
        if (publicAPI.state==='flow' || publicAPI.state==='expanded') {
          publicAPI.wrapper.style[xform] = 'translateY(' + (-offset) + 'px)';
        }
        //indicator.style[xform] = 'translateY(' + (offset * relative) + 'px)';
        publicAPI.checkPos();
      },

      /* */

      tap = function tap(e){
        if (e.target!==publicAPI.isiBtn&&e.target!==publicAPI.indBtn) {
          if (event.target.tagName.toLowerCase() === 'a') {
            return;
          }
          pressed = true;
          reference = ypos(e);

          velocity = amplitude = 0;
          frame = offset;
          timestamp = Date.now();
          clearInterval(ticker);
          ticker = setInterval(track,100);

          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      },

      /* */

      track = function track(){
        now = Date.now();
        elapsed = now - timestamp;
        timestamp = now;
        delta = offset - frame;
        frame = offset;
        v = 1000 * delta / (1 + elapsed);
        velocity = 0.8 * v + 0.2 * velocity;
      },

      /* */

      drag = function drag(e){
        if (pressed) {
          y = ypos(e);
          delta = reference - y;
          if (delta > 2 || delta < -2) {
            reference = y;
            scroll(offset + delta);
          }
        }
        e.preventDefault();
        e.stopPropagation();
        return false;
      },

      /* */

      release = function release(e){
        
        if (event.target.tagName.toLowerCase() === 'a') {
          return;
        }

        pressed = false;

        clearInterval(ticker);
        if (velocity > 10 || velocity < -10) {
          amplitude = 0.8 * velocity;
          target = Math.round(offset + amplitude);
          timestamp = Date.now();
          requestAnimationFrame(autoScroll);
        }

        e.preventDefault();
        e.stopPropagation();
        return false;
      },

      /* */

      autoScroll = function autoScroll(){
        if (amplitude) {
          elapsed = Date.now() - timestamp;
          delta = -amplitude * Math.exp(-elapsed / timeConstant);
          if (delta > 0.5 || delta < -0.5) {
            scroll(target + delta);
            requestAnimationFrame(autoScroll);
          } else {
            scroll(target);
          }
        }
      },

      /* */

      calculateSingleCrossover = function calculateSingleCrossover(){
        var co;
        co = (publicAPI.position.top - currentView.height) + (currentView.height - pinnedTop);
        return co;
      },

      /*  */

      initializeButton = function initializeButton(which){
        /* Check if the options object contains the expandBtn property, if so, check if it's 
           an element/node. If it is not an element, we check the document for the selector. 
           If it doesn't exist, we create a new element and set up the properties */
        if (options[which]) {
          publicAPI[which] = isElement(options[which]) || isNode(options[which]) ? options[which] : document.querySelector(options[which]);
        } else {
          publicAPI[which] = publicAPI.createBtn();
        }
        publicAPI[which+'HTML'] = publicAPI[which].innerHTML;
        if (which==='isiBtn') {
          publicAPI[which].onclick = publicAPI.expandISI.bind(publicAPI);
        }
        if (which==='indBtn') {
          publicAPI[which].onclick = publicAPI.expandIND.bind(publicAPI);
        }
        publicAPI[which+'Dim'] = publicAPI[which].getBoundingClientRect();
      },

      /* */

      initializeIndications = function initializeIndications(){
        publicAPI.mobileInd = isElement(options.mobileIndication) || isNode(options.mobileIndication) ? options.mobileIndication : document.querySelector(options.mobileIndication);
        publicAPI.mainInd = isElement(options.mainIndication) || isNode(options.mainIndication) ? options.mainIndication : document.querySelector(options.mainIndication);
      },

      /*
        Calculates the layout of ISI (pinned and expanded height) and generates the needed 
        elements, pinning the ISI as the last step.
      */

      buildISI = function buildISI(rebuild) {
        /* scroll function setup */
        relative = (innerHeight - 30) / max;
        if (!rebuild) {
          console.log(checkBrowser());
          /* Check to see if standard transforms are supported, if not, find the apprp. prefix */
          ['webkit', 'Moz', 'O', 'ms'].every(function (prefix) {
            var e = prefix + 'Transform';
            if (typeof view.style[e] !== 'undefined') {
                xform = e;
                return false;
            }
            return true;
          });
          /* Initialize event listeners for scrolling */
          if (typeof window.ontouchstart !== 'undefined') {
            view.addEventListener('touchstart', tap);
            view.addEventListener('touchmove', drag);
            view.addEventListener('touchend', release);
            publicAPI.wrapper.addEventListener('touchstart', tap);
            publicAPI.wrapper.addEventListener('touchmove', drag);
            publicAPI.wrapper.addEventListener('touchend', release);
            isMobile = true;
          }
        }
        
        /* ISI setup */

        currentView = viewport();
        initializeIndications();
        applyBreakpoint(calculateBreakpoint());
        if (!rebuild) {
          /* Grab the wrapper's parent node for insert of dummy content when pinning the ISI */
          publicAPI.parent = publicAPI.wrapper.parentNode;
          /* Add the event listener to check for user scrolling */
          window.onscroll = scrollResponder;
          /* Listen for resize events */
          window.onresize = resizeResponder;
          /* Listen for orientation changes */
          window.addEventListener("orientationchange", orientationResponder, false);
          initializeButton('isiBtn');
          initializeButton('indBtn');
        }
        if (rebuild) {
          publicAPI.unpin();
        }
        /* Run an initial check so the ISI is pinned on page load if it should be */
        publicAPI.position = publicAPI.wrapper.getBoundingClientRect();
        mobileCrossover = calculateSingleCrossover();
        publicAPI.checkPos();
      };

  var publicAPI = {

    /* Set up the request for loading the ISI text from local file */
    req: new XMLHttpRequest(),

    initialPosition: {},

    /* This variable holds the markup for the ISI for any processing or changes */
    isiMarkup: '',

    /* Holds the wrapper element from the main page that the ISI content is loaded into */
    wrapper: isElement(options.wrapper) || isNode(options.wrapper) ? options.wrapper : document.querySelector(options.wrapper),

    /* Holds the parent element for the wrapper for inserting and removing the dummy block
       (keeps scrolling and page size consistent while ISI is pinned) */
    parent: {},

    /* Holds the folding indication for display on mobile devices.  mobileStacking option
       in breakpoints controls display of this block. Main indication is not displayed when
       mobileIndication is visible. */
    mobileInd: null,

    /* The main indication block.  Displayed when mobileStacking is set to false */
    mainInd: null,

    /* File path for the ISI markup/text. Defaults to js/pinned_isi/isi.txt if no path is specified */
    filePath: options.filePath ? options.filePath : "js/pinned_isi/isi.txt",

    /* Breakpoints and related style information for various screen sizes. Defaults to a catch-all setting
       in case values are not specified. */
    breakpoints: options.breakpoints ? options.breakpoints : {
        all: {

      }
    },

    /* Holds the expand button element for toggling ISI (only displays on pinned state) */
    isiBtn: null,

    /* Holds the innerHTML of the expand button for restoration */
    isiBtnHTML: null,

    isiBtnDim: {},

    /* Holds the expand button element for toggling the indication in mobile layouts 
       (only displays in pinned state) */
    indBtn: null,

    indBtnHTML: null,

    indBtnDim: {},

    /* Holds state information.  Possible states are "pinned", "expanded", and "flow" */
    state: '',
    prevState: '',

    /* */

    checkPos: function checkPos() {
      /* Make sure scroll functions have proper element height for view */
      max = parseInt(getComputedStyle(pageBody).height, 10) - innerHeight;
      /*get current ISI position on page */
      this.position = this.wrapper.getBoundingClientRect();
      /*if the top is higher than the bottom of the view, set to true */
      if (isMobile) {
        isInView = ((this.position.top-currentView.height)-offset) < currentView.height || this.state === 'expanded' ? true : false;
      } else {
        isInView = this.position.top < currentView.height || this.state === 'expanded' ? true : false;
      }
      /*if the ISI isn't visible on screen, pin it. */
      if (!isInView) {
        this.pin();
        return;
      } else {
        /* If the ISI is expanded, do nothing */
        if (this.state === 'expanded') {
          return;
        } else {
          /* Check to make sure the dummy block has been inserted within the page.  If it has,
             we can check the position against the pinned ISI position, and drop the ISI back
             into the flow as soon as it scrolls into view, otherwise, we do nothing. */
          if (dummy.parentElement) {
            if (isMobile) {
              if (offset<mobileCrossover) {
                return;
              } else {
                this.unpin();
              }
            } else {
              currentPosition = dummy.getBoundingClientRect();
              if (currentPosition.top>this.position.top) {
                return;
              } else {
                this.unpin();
              }
            }
          } else {
            /* This check covers the small portion of time when the content may be on screen, but
               resides below the pinned height, in which case we want to pin it.  This keeps the 
               effect from jumping when the content scrolls off screen. */
            if (isMobile) {
                if (offset<mobileCrossover) {
                  this.pin();
                } else {
                    if (this.state!=='flow') {
                      this.flow();
                    }
                }
            } else {
              if (this.position.top>pinnedTop) {
                this.pin();
              } else {
                if (this.state!=='flow') {
                  this.flow();
                }
              }
            }
          }
        } 
      }
    },

    /* */

    createBtn: function createBtn() {
      var newBtn = document.createElement('a');
      return newBtn;
    },

    /* */

    expandISI: function expandISI(e) {
      if (dummy.parentElement) {
        this.state = 'expanded';
        this.parent.removeChild(dummy);
        applyStyles();
        if (!isMobile) {
          view.style.height = styleProps.expanded.top;
          view.style.overflow = 'hidden';
        } else {
          this.position = this.wrapper.getBoundingClientRect();
          view.style.height = String(this.position.height)+'px';
          view.style.padding = '0';
          view.style.border = 'none'
          view.style.overflow = 'hidden';
        }
        if (this.isiBtn && this.indBtn) {
          applyExpandBtnStyles();
          this.isiBtn.innerHTML = retractTextExp;
          this.indBtn.innerHTML = expandTextExp;
          this.isiBtn.onclick = this.retract.bind(this);
          this.isiBtn.ontouchstart = this.retract.bind(this);
          this.indBtn.onclick = this.expandIND.bind(this);
          this.indBtn.ontouchstart = this.expandIND.bind(this);
        } else if (this.isiBtn) {
          applyExpandBtnStyles();
          this.isiBtn.innerHTML = retractTextExp;
          this.isiBtn.onclick = this.retract.bind(this);
          this.isiBtn.ontouchstart = this.retract.bind(this);
        }
        window.scrollTo( 0, 0 );
      }
    },

    setIndExpState: function setIndExpState(){
      if (this.isiBtn) {
        this.isiBtn.style.display = 'none';
        applyExpandBtnStyles();
        this.isiBtn.innerHTML = retractTextExp;
        this.isiBtn.onclick = this.retract.bind(this);
        this.isiBtn.ontouchstart = this.retract.bind(this);
      }
      if (this.indBtn) {
        applyExpandBtnStyles();
        this.indBtn.innerHTML = retractTextExp;
        this.indBtn.onclick = this.retract.bind(this);
        this.indBtn.ontouchstart = this.retract.bind(this);
      }
      if (this.mobileInd) {
        this.mobileInd.style.height = 'auto';
        this.mobileInd.style.borderBottom = 'none';
      }
      window.scrollTo( 0, 0 );
    },

    /* */

    expandIND: function expandIND(e) {
      if (dummy.parentElement) {
        this.state = 'expanded';
        this.parent.removeChild(dummy);
        applyStyles();
        this.setIndExpState();
        if (!isMobile) {
          view.style.height = styleProps.expanded.top;
          view.style.overflow = 'hidden';
        } else {
          this.position = this.wrapper.getBoundingClientRect();
          view.style.height = String(this.position.height)+'px';
          view.style.padding = '0';
          view.style.border = 'none'
          view.style.overflow = 'hidden';
        }
      } else if (this.state === 'expanded') {
        this.setIndExpState();
        if (!isMobile) {
        } else {
          this.position = this.wrapper.getBoundingClientRect();
          view.style.height = this.position.height;
          view.style.padding = '0';
          view.style.border = 'none'
        }
      }
    },

    /* */

    retract: function retract(e) {
      if (!isMobile) {
        view.style.height = '';
        view.style.overflow = '';
      } else {
          view.style.height = '';
          view.style.overflow = '';
          view.style.padding = '';
          view.style.border = ''
        }
      if (this.isiBtn) {
        this.isiBtn.style.display = 'block';
        applyExpandBtnStyles();
      }
      this.pin();
    },

    /* */

    enable: function enable(){
      enableScroll();
    },

    /* */

    pin: function pin() {
      this.state = 'pinned';
      /* we need a dummy block the same size as the ISI content so that scrolling still 
      works smoothly and we don't hit an unexpected end of content */
      buildDummy();
      /* with the dummy in place we can safely pin the ISI */
      applyStyles();
      this.wrapper.style[xform] = 'translateY(0px)';
      if (this.isiBtn) {
        applyExpandBtnStyles();
        this.isiBtn.innerHTML = expandTextPinned;
        this.isiBtn.onclick = this.expandISI.bind(this);
        this.isiBtn.ontouchstart = this.expandISI.bind(this);
      }
      if (this.indBtn) {
        applyExpandBtnStyles();
        this.indBtn.innerHTML = expandTextPinned;
        this.indBtn.onclick = this.expandIND.bind(this);
        this.indBtn.ontouchstart = this.expandIND.bind(this);
      }
      if (this.mobileInd) {
        this.mobileInd.style.height = '';
      }
    },

    /* */

    unpin: function unpin() {
      this.state = 'flow';
      /* Remove the dummy element from the document flow and restore original position */
      this.parent.removeChild(dummy);
      applyStyles();
      this.wrapper.style[xform] = 'translateY(' + (-offset) + 'px)';
      if (this.isiBtn) {
        applyExpandBtnStyles();
        this.isiBtn.innerHTML = retractTextFlow;
        this.isiBtn.style.height = this.isiBtnDim.height + 'px';
        this.isiBtn.style.width = this.isiBtnDim.width + 'px';
      }
      if (this.mobileInd) {
        this.mobileInd.style.height = 'auto';
      }
    },

    /* Public method, sets up flow styles. This method drops the ISI content back into the 
       document flow. */

    flow: function flow() {
      this.state = 'flow';
      applyStyles();
      if (this.isiBtn) {
        applyExpandBtnStyles();
        this.isiBtn.innerHTML = expandTextFlow;
        this.isiBtn.style.height = this.isiBtnDim.height + 'px';
        this.isiBtn.style.width = this.isiBtnDim.width + 'px';
      }
      if (this.indBtn) {
        applyExpandBtnStyles();
        this.indBtn.innerHTML = expandTextFlow;
        this.indBtn.style.height = this.indBtnDim.height + 'px';
        this.indBtn.style.width = this.indBtnDim.width + 'px';
      }
    }

  };

  /* */

  loadText();

  /* */

  return publicAPI;

}(isiOptions));
