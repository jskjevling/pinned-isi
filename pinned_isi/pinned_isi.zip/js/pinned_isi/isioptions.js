var isiOptions = {
    wrapper: "#pinned-isi-footer",
    mobileIndication: ".mobile-ind",
    mainIndication: ".main-ind",
    isiBtn: ".isi-btn",
    indBtn: ".ind-btn",
    filePath: "isi.html",
    breakpoints: {
        large: {
            maxWidth: 999999,
            minWidth: 1005,
            mobileStacking: false,
            pinned: {
                isi: {
                    top: "66%",
                    position: "fixed",
                    borderTop: ""
                },
                expandBtn: {
                    width: '114px',
                    backgroundColor: '#a6afd6',
                    cursor: 'pointer',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: 'Expand +',
                retractText: 'Return -',
                customStyles: {

                }
            },
            expanded: {
                isi: {
                    top: "8px",
                    position: "absolute"
                },
                expandBtn: {
                    width: '114px',
                    backgroundColor: '#a6afd6',
                    cursor: 'pointer',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: 'Expand +',
                retractText: 'Return -',
                customStyles: {

                }
            },
            flow: {
                isi: {
                    top: "",
                    position: "static",
                    borderTop: "none",
                },
                expandBtn: {
                    width: '114px',
                    backgroundColor: '#fff',
                    cursor: 'default',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: '',
                retractText: '',
                customStyles: {

                }
            }
        },
        mobile: {
            maxWidth: 1004,
            minWidth: 0,
            mobileStacking: true,
            pinned: {
                isi: {
                    top: "66%",
                    position: "fixed",
                    borderTop: ''
                },
                expandBtn: {
                    width: '44px',
                    backgroundColor: '#a6afd6',
                    cursor: 'pointer',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: '+',
                retractText: '-',
                customStyles: {
                    element: {
                        selector: '.mobile-ind',
                        styles: {
                            borderBottom: ''
                        }
                    }
                }
            },
            expanded: {
                isi: {
                    top: "8px",
                    position: "absolute"
                },
                expandBtn: {
                    width: '44px',
                    backgroundColor: '#a6afd6',
                    cursor: 'pointer',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: '+',
                retractText: '-',
                customStyles: {

                }
            },
            flow: {
                isi: {
                    top: "",
                    position: "static",
                    borderTop: "none"
                },
                expandBtn: {
                    width: '44px',
                    backgroundColor: '#fff',
                    cursor: 'default',
                    transition: 'background-color .25s ease-in-out'
                },
                expandText: '',
                retractText: '',
                customStyles: {
                    element: {
                        selector: '.mobile-ind',
                        styles: {
                            borderBottom: 'none'
                        }
                    }
                }
            }
        }
    },
    expandIndicator: {
        expandImg: '',
        retractImg: ''
    }
};
